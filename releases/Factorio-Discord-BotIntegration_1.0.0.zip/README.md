# Factorio-Discord-BotIntegration

This is a mod that allows the Discord [AwF Bot](https://github.com/James-Hackett/AwF-Bot) to log achievements, deaths and many other things to work

## Features:

- Log completed research
- Log when a player dies
- Allow integration with [AwF Bot](https://github.com/James-Hackett/AwF-Bot) (show deaths, research in Discord)
- Is developed by the same people as the bot, which allows better integration
